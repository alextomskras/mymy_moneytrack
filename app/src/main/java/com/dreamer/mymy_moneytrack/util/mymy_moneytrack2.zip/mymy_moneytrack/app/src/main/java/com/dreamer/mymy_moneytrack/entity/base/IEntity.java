package com.dreamer.mymy_moneytrack.entity.base;

/**
 * Interface to represent contract of abstract entity.
 * Created on 2/15/16.
 *
 * @author Evgenii Kanivets
 */
public interface IEntity {
    long getId();
}